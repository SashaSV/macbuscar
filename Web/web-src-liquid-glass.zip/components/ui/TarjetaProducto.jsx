'use client';
import { TIENDAS, TAG_COLORS } from '../shared/constants';
import { getMejor, getPrecioMap, getPriceValue } from '../shared/utils';
import { getProductIcon, TAG_BADGE } from '../shared/categoryIcons';

const CAT_LABEL = {
  iphone: 'IPHONE',
  mac: 'MAC',
  ipad: 'IPAD',
  watch: 'WATCH',
  airpods: 'AIRPODS',
  accesorios: 'ACCESORIOS',
};

export default function TarjetaProducto({ prod, precios, scrapeStatus, onClick }) {
  const pP = precios[prod.id] || getPrecioMap(prod);
  const pS = scrapeStatus?.[prod.id] || {};
  const v = Object.values(pP).map(getPriceValue).filter(Boolean);
  const minP = v.length ? Math.min(...v) : null;
  const maxP = v.length ? Math.max(...v) : null;
  const [mejId] = getMejor(pP);
  const mejT = TIENDAS.find(t => t.id === mejId);
  const isLoading = Object.values(pS).some(s => s === 'loading');

  const iconClass = getProductIcon(prod);
  const tagStyle = TAG_BADGE[prod.tag];

  // Real photo if available (from scraper)
  const fotos = Array.isArray(prod.fotos) ? prod.fotos : [];
  const hasRealPhoto = fotos.length > 0 && typeof fotos[0] === 'string' && fotos[0].startsWith('http');

  return (
    <div
      onClick={onClick}
      style={{
        background: 'rgba(255,255,255,0.55)',
        backdropFilter: 'blur(30px) saturate(180%)',
        WebkitBackdropFilter: 'blur(30px) saturate(180%)',
        border: '0.5px solid rgba(255,255,255,0.85)',
        borderRadius: 20,
        overflow: 'hidden',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.95), 0 4px 16px rgba(0,0,0,0.04)',
        cursor: 'pointer',
        position: 'relative',
        transition: 'transform .3s ease, box-shadow .3s ease',
        animation: 'slideUp .3s ease',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = 'inset 0 1px 0 rgba(255,255,255,0.95), 0 12px 28px rgba(0,0,0,0.08)';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = 'inset 0 1px 0 rgba(255,255,255,0.95), 0 4px 16px rgba(0,0,0,0.04)';
      }}
    >
      {/* Image area */}
      <div style={{
        aspectRatio: '1',
        background: 'rgba(255,255,255,0.4)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: hasRealPhoto ? 18 : 0,
        position: 'relative',
        borderBottom: '0.5px solid rgba(255,255,255,0.5)',
      }}>
        {hasRealPhoto ? (
          <img
            src={fotos[0]}
            alt={prod.nombre}
            style={{
              maxWidth: '100%',
              maxHeight: '100%',
              objectFit: 'contain',
              filter: 'drop-shadow(0 8px 16px rgba(0,0,0,0.08))',
            }}
            onError={e => {
              const parent = e.target.parentElement;
              e.target.remove();
              const icon = document.createElement('i');
              icon.className = `ti ${iconClass}`;
              icon.style.fontSize = '160px';
              icon.style.color = '#1d1d1f';
              parent.appendChild(icon);
            }}
          />
        ) : (
          <i className={`ti ${iconClass}`} aria-hidden="true" style={{ fontSize: 160, color: '#1d1d1f' }} />
        )}

        {isLoading && (
          <div style={{
            position: 'absolute', top: 10, left: 10,
            background: 'rgba(59,130,246,0.9)', color: '#fff',
            fontSize: 10, fontWeight: 500, padding: '3px 9px',
            borderRadius: 980,
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <i className="ti ti-loader-2" style={{ fontSize: 11, animation: 'spin 1s linear infinite' }} aria-hidden="true" />
            Scraping
          </div>
        )}
      </div>

      {/* Info area */}
      <div style={{ padding: '12px 14px 14px', position: 'relative' }}>
        {/* Sticker badge on the seam */}
        {prod.tag && tagStyle && (
          <div style={{
            position: 'absolute',
            top: -14,
            right: 12,
            background: tagStyle.bg,
            border: `0.5px solid ${tagStyle.border}`,
            color: '#fff',
            fontSize: 10,
            fontWeight: 500,
            padding: '4px 11px',
            borderRadius: 980,
            boxShadow: `0 4px 12px ${tagStyle.shadow}`,
            backdropFilter: 'blur(20px)',
            letterSpacing: 0.2,
          }}>
            {prod.tag}
          </div>
        )}

        <div style={{
          fontSize: 10,
          color: 'rgba(29,29,31,0.5)',
          marginBottom: 2,
          letterSpacing: 0.3,
          fontWeight: 500,
        }}>
          {CAT_LABEL[prod.cat] || prod.cat?.toUpperCase() || ''}
        </div>

        <div style={{
          fontSize: 13,
          fontWeight: 500,
          lineHeight: 1.3,
          marginBottom: 8,
          color: '#1d1d1f',
          minHeight: 32,
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
        }}>
          {prod.nombre}
        </div>

        {prod.rating > 0 && (
          <div style={{ fontSize: 11, color: '#f59e0b', marginBottom: 4 }}>
            {'★'.repeat(Math.round(prod.rating))}
            <span style={{ color: 'rgba(29,29,31,0.4)', marginLeft: 4 }}>{prod.rating}</span>
          </div>
        )}

        <div style={{
          fontSize: 16,
          fontWeight: 500,
          letterSpacing: -0.3,
          color: '#1d1d1f',
        }}>
          {isLoading ? '—' : (minP != null ? `${minP.toLocaleString('es-ES')} €` : '—')}
        </div>

        {!isLoading && minP != null && maxP != null && maxP > minP && (
          <div style={{
            fontSize: 10,
            color: '#047857',
            fontWeight: 500,
            marginTop: 3,
          }}>
            −{Math.round(maxP - minP)} € · {mejT?.nombre || ''}
          </div>
        )}
        {!isLoading && minP != null && (maxP === minP || maxP == null) && mejT && (
          <div style={{ fontSize: 10, color: 'rgba(29,29,31,0.4)', marginTop: 3 }}>
            en {mejT.nombre}
          </div>
        )}
      </div>
    </div>
  );
}
